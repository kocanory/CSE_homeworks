#-*- coding:utf-8 -*-
import os

def CureDelete(fname):
    return os.remove(fname) #인자로 받은 파일 이름에 해당하는 파일 삭제