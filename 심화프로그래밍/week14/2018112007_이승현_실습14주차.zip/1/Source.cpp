#include <iostream>

using namespace std;


class Resource
{
public:
	int m_data[100]; //�迭 ����
	Resource()
	{
		cout << "Resource constructed" << endl; //Ŭ���� ������
	}

	~Resource()
	{
		cout << "Resource destroyed" << endl;//Ŭ���� �Ҹ���
	}


};

template<class t>
class AutoPtr
{
public:
	t *m_ptr = nullptr;

public:
	AutoPtr(t *ptr = nullptr) : m_ptr(ptr)
	{

	}

	~AutoPtr()
	{
		if (m_ptr != nullptr) delete m_ptr;
	}

	AutoPtr(AutoPtr&& a) : m_ptr(a.m_ptr)
	{
		a.m_ptr = nullptr;
	}

	AutoPtr& operator= (AutoPtr& a)
	{
		if (&a == this)
			return *this; //�ּҰ� ������� 

		if (!m_ptr) delete m_ptr; //�ּҰ� ������� �޸� ��ȯ

		m_ptr = a.m_ptr;
		a.m_ptr = nullptr; //move sementics

		return *this;
	}

	t& operator* () const { return *m_ptr; }
	t* operator->() const { return m_ptr; }
};

int main()
{
	AutoPtr<Resource> res1(new Resource);
	AutoPtr<Resource> res2;

	cout << "res1 : " << res1.m_ptr << endl;
	cout << "res2 : " << res2.m_ptr << endl;

	res2 = res1;

	cout << "res1 : " << res1.m_ptr << endl;
	cout << "res2 : " << res2.m_ptr << endl;

}