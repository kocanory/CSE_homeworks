#include <iostream>

using namespace std;

class Cat
{
private:
	char *name;
	int age;

public:
	Cat(char * _name, int age) : age(age)
	{
		name = new char[strlen(_name) + 1];
		strcpy(name, _name);
	}

	void print()
	{
		cout << "name : " << name << endl;
		cout << "age : " << age << endl;
	}
};

template<class t>
void MySwap(t &a, t &b)
{
	
	cout << "move constructor" << endl;
	t tmp{ std::move(a) };//�̵� ������ ����
	cout << "move assignment" << endl;
	a = std::move(b); //�̵� ����
	cout << "move assignment" << endl;
	b = std::move(tmp); //�̵� ����
}

int main()
{
	Cat cat1("Alice", 2);
	Cat cat2("Bobby", 3);

	cat1.print();
	cat2.print();
	cout << endl;

	MySwap(cat1, cat2);

	cout << endl;
	cat1.print();
	cat2.print();

	return 0;
}

