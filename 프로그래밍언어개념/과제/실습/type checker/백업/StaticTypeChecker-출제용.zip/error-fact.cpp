int main ( ) {
    float n, i;
    int i, j;
    n = 3.0 + 7;
    i = 1.0;
    f = 1.0;
    j = 0.0 + 1;
    while (i < n) {
        i = i + 1.0 + 'c';
        f = f * i;
    }

    while (j < n) {
        j = j + 1 + 'c';
        j = f * i;
        j = j * n;
    }
}
