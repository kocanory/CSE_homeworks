int main ( ) {
  n = 3;
  i = 1;
  f = 1.0;
  while (i < n) {
    i = i + 1;
    f = f * float(i);
  }
}
