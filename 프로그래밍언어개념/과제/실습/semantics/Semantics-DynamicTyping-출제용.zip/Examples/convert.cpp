int main ( ) {
    float f;
    int i;
    char c;
    c = 'a';
    i = 77;
    f = i - int(c);
}
