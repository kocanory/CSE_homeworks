int main () {
   int c;
   float b;
   c = 1;
   b = -float(c);
}
