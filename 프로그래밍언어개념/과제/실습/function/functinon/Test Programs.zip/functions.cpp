   int h, i;
   void A(int x, int y) {
      bool i,  j;
      B(h);
   }
   void B(int w) {
      int j, k;
      i = 2*w;
      w = w + 1;  
   }
   int main () {
      int a, b;
      h = 5; a = 3; b = 2;
      A(a, b);
   }

