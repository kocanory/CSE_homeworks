package week11;

public class ImproveEditor extends Editor {
	
	public void Appen(String str, int line)
	{
		String[] array = temp.split("\\n"); //엔터 개행 문자를 기준으로 분할
		if(line <= array.length) //입력받은 줄의 수가 스트링 배열의 크기보다 작을 경우 실행
		{
			if(line == 0)//0번쨰 줄 일경우 0번째 줄 앞에 삽입
		{
			temp2 = new String(str);
			for(int j = 0 ;j < array.length;j++)
			{
				temp2 = temp2.concat(array[j]);
			}
			strTemp = new String(temp2);	
			System.out.println(strTemp);
		}
			else //그렇지 않으면 입력받은 줄 앞에 삽입
			{
			temp2 = new String(array[0]);
			
			for(int i = 1 ; i < line ; i++)
			{
				temp2 = temp2.concat(array[i]);
			}
		
				temp2 = temp2.concat(str);
		
			for(int j = line ;j < array.length;j++)
			{
				temp2 = temp2.concat(array[j]);
			}
				strTemp = new String(temp2);	
				System.out.println(strTemp);
			}
		}
		else
		{
			System.out.println("Error");
		}
	}
	
	void SearchWord(String word, int line)
	{
		String[] array = temp.split("\\n"); //엔터 개행 문자를 기준으로 분할
		
		if(line <= array.length)
		{
			compare = array[line].indexOf(word); //문자열 위치 탐색
		
		if(compare != -1)
		{
			System.out.print("index = " + compare);
			for(int i = compare + 1;i < compare + word.length() ; i++)
			{
				System.out.print(", index = " + i); //만약 문자열이 test.txt에 있을 경우 배열의 위치를 출력 
			}
			System.out.println("");
			System.out.println("");
		}
		else
		{
			System.out.println("not existance"); //만약 문자열이 test.txt에 없을 경우 출력
			System.out.println("");				
		}
		}
		
		else
		{
			System.out.println("Error");
		}
		
	}

}
