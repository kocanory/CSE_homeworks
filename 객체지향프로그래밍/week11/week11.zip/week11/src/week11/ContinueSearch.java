package week11;

import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

public class ContinueSearch extends Editor{ //Editor 클래스 상속
	
	void searchWord()
	{
		while(true)//계속 반복한다
		{	
		try {
				writer = new FileWriter(FILE_OUT_PATH);//파일 입력 기능을 위한 객체를 생성 및 초기화
				in = new FileInputStream(TEXT_PATH);//파일 입력 기능을 위한 객체를 생성 및 초기화, 텍스트 파일을 불러옴;
				System.out.print("검색할 단어를 입력하세요: ");
				s2 = new Scanner(System.in);//스캐너 객체를 생성 및 초기화
				input = s2.next();//입력받은 문자를 변수 input에 저장
					
				while(in.read(readBuffer, 0,  readBuffer.length) != -1)
				{
					strTemp = new String(readBuffer); // String 객체를 생성 및 초기화, test.txt 내용을 저장 
				}
				strTemp = strTemp.replaceAll("\r\n", ""); //중간에 줄바꿈이 있다면 제거

				compare = strTemp.indexOf(input); //test.txt 내용과 자신이 입력한 문자열을 비교
				if(compare != -1)
				{
					System.out.print("index = " + compare);
					for(int i1 = compare + 1;i1 < compare + input.length() ; i1++)
					{
						System.out.print(", index = " + i1); //만약 문자열이 test.txt에 있을 경우 배열의 위치를 출력 
					}
					System.out.println("");
					System.out.println("");
					
					in.close();//파일 입력 종료
					bufferedInputStream.close(); //파일 입력 종료	
					writer.close();//파일 쓰기 종료
					
				}
				else
				{
					System.out.println("not existance"); //만약 문자열이 test.txt에 없을 경우 출력
					System.out.println("");
					break;//반복문 탈출
				}	
				
		}

				catch (IOException e) {
					e.printStackTrace();
				}
		}
	}
}
