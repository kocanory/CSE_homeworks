package week8;
/**
 * 
 * @author 2018112007 이승현
 *
 */

public class project1 {
	
	public static void main(String[] args)
	{
		Fraction f1 = new Fraction(8, 3);//분자 8, 분모 3인 분수 객체를 할당 및 초기화
		Fraction f2 = new Fraction(4, 3);//분자 4, 분모 3인 분수 객체를 할당 및 초기화
		
		f1.add(f2);//분수 더하기 메소드 실행
		System.out.print("변환 전 : ");
		System.out.println(f1);//분수의 합을 출력
		transpose(f1);//기약분수로 변환
		System.out.print("변환 후 : ");
		System.out.println(f1);//기약분수로 변환된 분수를 출력
		
		f1.sub(f2);//분수 뺴기 메소드 실행
		System.out.print("변환 전 : ");
		System.out.println(f1);//분수의 차를 출력
		transpose(f1);//기약분수로 변환
		System.out.print("변환 후 : ");
		System.out.println(f1);//기약분수로 변환된 분수를 출력
		
		f1.mul(f2);//분수 곱하기 메소드 실행
		System.out.print("변환 전 : ");
		System.out.println(f1);//분수의 곱을 출력
		transpose(f1);//기약분수로 변환
		System.out.print("변환 후 : ");
		System.out.println(f1);//기약분수로 변환된 분수를 출력
		
		f1.div(f2);//분수 나누기 메소드 실행
		System.out.print("변환 전 : ");
		System.out.println(f1);//분수의 나눗셈 결과를 출력
		transpose(f1);//기약분수로 변환
		System.out.print("변환 후 : ");
		System.out.println(f1);//기약분수로 변환된 분수를 출력
	}	
	
	static int GCD(int n1, int n2)//최대공약수 구하기
	{
		if(n1 > n2)//왼쪽이 오른쪽보다 클경우
		{
			if(n2 == 0)
			  return n1;
		    else 
			  return GCD(n2, n1 % n2);
	    }
		
		else if (n2 > n1)//오른쪽이 왼쪽보다 클경우
		{
			if(n1 == 0)
				  return n2;
			    else 
				  return GCD(n1, n2 % n1);
		}
		else//서로 같을 경우
			return n2;
	}
	

	static void transpose(Fraction F1)
	{
		int i = GCD(F1.numerator,F1.denominator); //정수형 변수 i에 매개변수로 들어온 분수 객체의 분자와 분모의 최대공약수를 저장
		F1.numerator /= i; 
		F1.denominator /= i; //분모, 분자 각각에 최대공약수를 나눈다.
	}
	
	static class Fraction
	{
		public int numerator;
		public int denominator; //분수 객체의 필드를 정의(분모, 분자)
		
		public Fraction(int n1, int n2)
		{
			numerator = n1;
			denominator = n2; //생성자를 정의
		}
		
		void add(Fraction F1)
		{			
			System.out.println("< add function >");
			if(denominator == F1.denominator)
			{
				numerator = numerator + F1.numerator; //분모가 같을경우 분자만 더한다
			}
			else
			{
				numerator = numerator * F1.denominator + F1.numerator * denominator;
				denominator *= F1.denominator;	//분모가 다를 경우 통분하고, 분자를 더해준다
			}
			
		}
		
		void mul(Fraction F1)
		{
			System.out.println("< multiply function >");
			numerator *= F1.numerator;
			denominator *= F1.denominator; //분자는 분자끼리, 분모는 분모끼리 곱한다
		}
		
		void sub(Fraction F1)
		{
			System.out.println("< subtract function >");
			if(denominator == F1.denominator)
			{
				numerator -= F1.numerator;//분모가 같을경우 분자끼리 뺀다
			}
			else
			{
				numerator = numerator * F1.denominator - F1.numerator * denominator;
				denominator *= F1.denominator;//분모가 다를경우 통분하고, 분자를 더해준다
			}
		}
		
		void div(Fraction F1)
		{
			System.out.println("< divide function >");
			numerator *= F1.denominator;
			denominator *= F1.numerator;
			//나눗셈은 역수해서 곱해주는 것과 같으므로 분자는 매개변수로 들어온 분수 객체의 분모와, 분모는 매개변수로 들어온 분수 객체의 분자와 곱해준다. 
		}
		
		
		public String toString()
		{
			if(denominator == 1)
				return "" + numerator + "\n"; //만약 분모가 1일때 분자만 출력
			else
				return numerator + " / " + denominator + "\n"; //그렇지 않으면 분자 / 분모 로 출력
		}
	}
}