package week10;

import java.io.IOException;

public class EditorTest {
	public static void main(String[] args) throws IOException
	{
		Menu menu = new Menu();	//Menu 객체를 생성 및 초기화
		menu.menuStart();//Menu 객체의 menuStart() 실행
		
	}
}