package week10;

import java.io.IOException;
import java.util.Scanner;

public class Menu extends Editor{ //Editor 클래스 상속
	boolean isExitProgram = false;
	final String MENU_TEXT = "\t\t===콘솔메뉴테스트===\n"
			+ "파일불러오기 (O), 단어검색(S), " + " 검색결과출력(P), 수정 후 결과 출력(R), 프로그램종료(Q)";
	
		void menuStart() throws IOException
		{
			while(!isExitProgram)
			{	
			
			System.out.println(MENU_TEXT);
			sc = new Scanner(System.in);//스캐너 객체를 생성 및 초기화
			findWord = sc.nextLine();
			switch(findWord)
			{
			case "O": case "o":
				System.out.print("불러올 파일명을 입력하세요: ");
				s1 = new Scanner(System.in);//스캐너 객체를 생성 및 초기화
				fileName = s1.next();
				if(fileName.equals(TEXT_PATH))
				{
					System.out.println("파일이 존재합니다.");
					break;
				}
				else
				{	
					while(!fileName.equals(TEXT_PATH))
						{
							System.out.print("파일이 존재하지 않습니다. 경로를 다시 입력하세요: "); //파일명이 다를 경우 출력
							fileName = s1.next();
							if(fileName.equals(TEXT_PATH))
							{
								System.out.println("파일이 존재합니다."); //파일명이 같을 경우 출력
								break;
							}
							
						}
					break;
				}			
			case "S" : case "s":
				searchWord();//단어를 찾는 메소드 실행
				break;
			case "P" : case "p":
				PrintWord();//찾은 단어와 순서 출력
				break;
			case "R" : case "r":
				replaceWord();//단어 교체 메소드를 실행
				printToFile();//파일에 쓰기
				break;
			case "Q": case "q":
				System.out.println("프로그램을 종료합니다. ");
				isExitProgram = true;//프로그램 종료
				break;
			default:
				System.out.println("알 수 없는 명령입니다. 한번 더 입력해주세요.");
				break;					
			}			
		}
	}
}