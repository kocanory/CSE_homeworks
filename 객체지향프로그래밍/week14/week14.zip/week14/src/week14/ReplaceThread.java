package week14;

public class ReplaceThread extends Editor implements Runnable{
		public void run()
		{
			this.replaceWord();
			System.out.println("Replace Thread!");
			this.printToFile();
		}
}
