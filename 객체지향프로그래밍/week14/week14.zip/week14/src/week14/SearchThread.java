package week14;

public class SearchThread extends Editor implements Runnable{
	public void run()
	{
		this.searchWord();
		System.out.println("Search Thread!");
	}
}
