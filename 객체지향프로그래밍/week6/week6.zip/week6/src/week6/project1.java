package week6;

import java.io.*; //입출력 패키지 임포트
import java.util.Scanner; //유틸 패키지 임포트
import java.util.Arrays;

/**
 * 
 * @author 2018112007 이승현
 *
 */

public class project1 {
	
	static BufferedWriter bufferedWriter;
	public static final String FILE_OUT_PATH = "d:\\output.txt";
	public static final String TEXT_PATH = "d:\\test.txt"; //불러올 텍스트 파일 설정
	public static final int BUFFER_SIZE = 1024; //버퍼 사이즈 설정
	
	public static boolean loadWritingFile(String path, boolean isAppend)
	{
		
		File textFile = new File(path);
		try
		{
			FileWriter fileWriter = new FileWriter(textFile, isAppend);
			bufferedWriter = new BufferedWriter(fileWriter);
		}
		catch(IOException e)
		{
			e.printStackTrace();
			return false;
		}
		
		return true;
	}
	
	public static void main(String[] args) throws IOException// 예외 선언
	{
		int[] num;
		String findWord, fileName, input = null, select, number;//String을 선언
		Scanner sc = null; //Scanner 선언
		Scanner s1 = null;//Scanner 선언
		Scanner s2 = null;//Scanner 선언
		Scanner c = null;//Scanner 선언
		String strTemp = null; //String을 선언
		String strTemp2 = null;//String을 선언
		int compare = 0;
		
		byte[] readBuffer = new byte[BUFFER_SIZE];
		FileInputStream in = new FileInputStream(TEXT_PATH);//파일 입력 기능을 위한 객체를 생성 및 초기화, 텍스트 파일을 불러옴
		BufferedInputStream bufferedInputStream = new BufferedInputStream(in, BUFFER_SIZE);; //버퍼를 이용한 입력 객체를 생성 및 초기화
		
		FileWriter writer = new FileWriter(FILE_OUT_PATH);
		final String MENU_TEXT = "\t\t===콘솔메뉴테스트===\n"
				+ "파일불러오기 (O), 단어검색(S), " + " 검색결과출력(P), 프로그램종료(Q)";
			
		
			Boolean isExitProgram = false;
			while(!isExitProgram)
			{	
				System.out.println(MENU_TEXT);
				sc = new Scanner(System.in);//스캐너 객체를 생성 및 초기화
				findWord = sc.nextLine();
				switch(findWord)
				{
				case "O": case "o":
					System.out.print("불러올 파일명을 입력하세요: ");
					s1 = new Scanner(System.in);//스캐너 객체를 생성 및 초기화
					fileName = s1.next();
					if(fileName.equals(TEXT_PATH))
					{
						System.out.println("파일이 존재합니다.");
						break;
					}
					else
					{	
						while(!fileName.equals(TEXT_PATH))
							{
								System.out.print("파일이 존재하지 않습니다. 경로를 다시 입력하세요: "); //파일명이 다를 경우 출력
								fileName = s1.next();
								if(fileName.equals(TEXT_PATH))
								{
									System.out.println("파일이 존재합니다."); //파일명이 같을 경우 출력
									break;
								}
								
							}
						break;
					}

				
				case "S" : case "s":
					System.out.print("검색할 단어를 입력하세요: ");
					s2 = new Scanner(System.in);//스캐너 객체를 생성 및 초기화
					input = s2.next();//입력받은 문자를 변수 input에 저장

					while(bufferedInputStream.read(readBuffer, 0,  readBuffer.length) != -1)
					{
						strTemp = new String(readBuffer); // String 객체를 생성 및 초기화, test.txt 내용을 저장 
					}
				
					
					compare = strTemp.indexOf(input); //test.txt 내용과 자신이 입력한 문자열을 비교
					
					if(compare != -1)
					{
						System.out.print("index = " + compare);
						for(int i1 = compare + 1;i1 < compare + input.length() ; i1++)
						{
							System.out.print(", index = " + i1); //만약 문자열이 test.txt에 있을 경우 배열의 위치를 출력 
						}
						System.out.println("");
						System.out.println("");
					}
					else
					{
						System.out.println("not existance"); //만약 문자열이 test.txt에 없을 경우 출력
						System.out.println("");				
					}
					bufferedInputStream.close(); //파일 입력 종료								
					break;
				case "P" : case "p":

					System.out.println("저장할 파일명을 입력하세요: ");
					s1 = new Scanner(System.in); //스캐너 객체를 생성 및 초기화
					fileName = s1.next(); //입력한 문자열을 변수에 저장
					if(fileName.equals(FILE_OUT_PATH))
					{
						System.out.print("파일이 존재합니다. 붙여넣겠습니까? ");
						c = new Scanner(System.in);
						select = c.next();
						if(select.equals("Y") || select.equals("y")) //Y 또는 y 입력할 경우 실행
						{
							
							num = new int[input.length()];
							for(int i =0;i < input.length() ; i++)
							{
								num[i] = compare + i;
							}					
								number = Arrays.toString(num);
								
								writer.write(input);
								writer.write(number);
								writer.write(" 번째에 문자열이 존재합니다.");
						
								writer.close();
							break;
						}
						
						else if(select.equals("N") || select.equals("n")) //N 또는 n 입력할 경우 실행
						{
							num = new int[input.length()];
							for(int i =0;i < input.length() ; i++)
							{
								num[i] = compare + i;
							}					
								number = Arrays.toString(num);
								
								strTemp2 = number + " 번째에 문자열이 존재합니다.";
								if(loadWritingFile(FILE_OUT_PATH, false))
								{
									bufferedWriter.write(strTemp2); //배열의 위치를 출력
									bufferedWriter.close();
								}
								
								break;
						}
					
						c.close();
					}
					
					else
					{
						num = new int[input.length()];
						for(int i =0;i < input.length() ; i++)
						{
							num[i] = compare + i;
						}					
							number = Arrays.toString(num);
							
							strTemp2 = number + " 번째에 문자열이 존재합니다.";
							if(loadWritingFile(fileName, false))
							{
								bufferedWriter.write(strTemp2); //배열의 위치를 출력
								bufferedWriter.close();
							}
							break;
					}
				
				case "Q": case "q":
					System.out.println("프로그램을 종료합니다. ");
					isExitProgram = true;
					break;
				default:
					System.out.println("알 수 없는 명령입니다. 한번 더 입력해주세요.");
					break;					
				}	
				
				
		}
			sc.close();
			s1.close();
			s2.close();		

			}
	}