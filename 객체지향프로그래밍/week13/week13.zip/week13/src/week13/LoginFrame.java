package week13;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.*;

public class LoginFrame extends JFrame implements ActionListener{ //JFrame 상속, ActionListener 활용
	public static final String BTN_LOGIN_TEXT = "Login";
	private String id = "2018112007"; //아이디 설정
	private String password = "12345678"; //패스워드 설정
	JTextField tf_id = new JTextField(10);
	JPasswordField pf_pwd = new JPasswordField(8);
	JTextArea ta_info = new JTextArea(3, 25); //창 면적 설정
	JButton btn_login =	new JButton(BTN_LOGIN_TEXT);//Login 버튼 설정
	JPanel pn_content = new JPanel();
	
	public void actionPerformed(ActionEvent event)
	{
		if(event.getSource() == btn_login)
		{
			try
			{
				if(((id.equals(tf_id.getText()))) && (password.equals(pf_pwd.getText()))) //입력한 아이디와 패스워드가 설정값과 같을경우 성공 메시지 출력
					ta_info.setText("login successed");
				else
					ta_info.setText("login failed"); //그렇지 않으면 실패 메시지 출력
			}
			
			catch (Exception e1) {
			    System.out.println("false"); //예외처리기
			}
		}
	}
	
	public LoginFrame(String title) {
		super(title);
		btn_login.addActionListener(this);
		pn_content.add(new JLabel("아이디를 입력하세요  "));
		pn_content.add(tf_id);
		pn_content.add(new JLabel("비밀번호를 입력하세요  "));
		pn_content.add(pf_pwd);
		pn_content.add(ta_info);
		pn_content.add(btn_login);
		pn_content.setLayout((new FlowLayout()));
		add(pn_content);
		
		btn_login.addActionListener(this);
	}
	
	public static void main(String[] args)
	{
		LoginFrame f = new LoginFrame("로그인 화면");
		f.setSize(320, 200);
		f.setDefaultCloseOperation(EXIT_ON_CLOSE);
		f.setVisible(true);
	}
}
