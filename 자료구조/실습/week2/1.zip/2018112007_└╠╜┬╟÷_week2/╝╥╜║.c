#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <conio.h>
#include <ctype.h>
#include "header.h"

int main()
{
	char c;

	read_record(fname);

	printf("********** ���ɾ� ********** \n");
	printf("P: Print all records \n");
	printf("S: Search rfecord \n");
	printf("C: Change record \n");
	printf("W: Write record \n");
	printf("Q: Save and quit \n");
	printf("************************* \n");

	while (1)
	{
		printf("\nCommand> ");
		c = getch();
		putch(c);
		c = toupper(c);

		switch (c)
		{
		case 'P' :
			print_record();
			break;
		case 'S':
			search_record();
			break;
		case 'C':
			change_record();
			break;
		case 'W':
			write_record(fname);
			break;
		case 'Q':
			printf("\n");
			exit(1);
			break;

		default :
			printf("\nUnknown command ! \n");
			break;
		}
	}
}

void read_record(char *fname)
{
	int i = 0;
	FILE *ifp;

	ifp = fopen(fname, "r");
	while (fscanf(ifp,"%s %d %s", r[i].name, &r[i].id, r[i].grade) == 3)
		++i;

	num_record = i;
	fclose(ifp);
}

void print_record()
{
	printf("\n************************** \n");
	for (int i = 0; i < num_record; i++)
	{
		printf("%s   %d		%s\n", r[i].name, r[i].id, r[i].grade);
	}
	printf("**************************** \n");
}

void search_record()
{
	char name[10];
	printf("\n Search name: ");
	scanf("%s", name);
	
	for (int i = 0; i < num_record; i++)
	{
		if (!strcmp(r[i].name, name))
		{
			printf("	Name:	%s\n", r[i].name);
			printf("	ID:	%d\n", r[i].id);
			printf("	Grade:	%s\n", r[i].grade);
		}
	}
}

void change_record()
{
	char name[10];
	char grade[4];
	printf("\n Name: ");
	scanf("%s", name);

	for (int i = 0; i < num_record; i++)
	{
		if (!strcmp(r[i].name, name))
		{
			printf("Grade: ");
			scanf("%s", grade);
			strcpy(r[i].grade, grade);
		}
	}
}

void write_record(char *fname)
{
	
	FILE *ifp;

	ifp = fopen(fname, "w+");

	for (int i = 0; i < num_record; i++)
	{
		fprintf(ifp, "%s %d %s\n", r[i].name, r[i].id, r[i].grade);
	}
	fclose(ifp);

	printf("\n %d recoreds have written to grade.txt.", num_record);
}