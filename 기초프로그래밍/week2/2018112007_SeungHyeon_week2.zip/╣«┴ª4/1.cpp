#include <stdio.h>

int main()
{
	printf("    CCCCCCCC\n  CC        CC\nCC           CC\nCC\nCC\nCC           CC\n  CC        CC\n    CCCCCCC\n");
}