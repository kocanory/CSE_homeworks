#include <stdio.h>

int main()
{
	printf("1\n12\n123\n1234\n12345\n");
}