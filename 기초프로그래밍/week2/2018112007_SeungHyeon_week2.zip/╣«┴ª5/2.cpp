#include <stdio.h>

int main()
{
	printf("  1\n 121 \n12321\n 121 \n  1\n");
}