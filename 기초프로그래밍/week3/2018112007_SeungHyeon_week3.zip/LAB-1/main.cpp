#include <stdio.h>

int main(void)
{
	int a = 30, b = 43;
	int sum;
	sum = a + b;

	double x = 38.342, y = 45.345;
	double difference;
		difference = x - y;

		printf("��: %d\n", sum);
	    printf("��: %f\n", difference);

	return 0;
}