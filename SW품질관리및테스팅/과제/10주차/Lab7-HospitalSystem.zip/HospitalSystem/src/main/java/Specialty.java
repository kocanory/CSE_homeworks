/*
 * Pediatrics PED
 * General practice GEN
 * Cardiology CAR
 * Surgeon SUR
 * Psychiatry PSY
 * Dermatology DET
 * Ear, Nose, and Throat ENT
 * 
 */
public enum Specialty {
	PED,GEN,CAR,SUR,PSY,DET,ENT
}
