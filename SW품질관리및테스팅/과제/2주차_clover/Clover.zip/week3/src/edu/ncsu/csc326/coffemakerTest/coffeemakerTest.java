package edu.ncsu.csc326.coffemakerTest;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;
import edu.ncsu.csc326.coffeemaker.*;
import edu.ncsu.csc326.coffeemaker.exceptions.*;

public class coffeemakerTest {

	private CoffeeMaker c;
	
	private Recipe r1, r2, r3;
	
	
    private Recipe createRecipe(String name, int price, int amtCoffee, int amtMilk, int amtSugar, int amtChocolate) throws RecipeException {
		Recipe recipe = new Recipe();
		recipe.setName(name);
		recipe.setPrice(String.valueOf(price));
		recipe.setAmtCoffee(String.valueOf(amtCoffee));
		recipe.setAmtMilk(String.valueOf(amtMilk));
		recipe.setAmtSugar(String.valueOf(amtSugar));
		recipe.setAmtChocolate(String.valueOf(amtChocolate));
		return recipe;
    }
    
    @Before
	public void setUp() throws Exception
	{
		c = new CoffeeMaker();
		r1 = createRecipe("Latte", 5000, 2, 10, 3, 2);
		r2 = createRecipe("Americano", 1500, 16, 0, 0, 0);
		r3 = createRecipe("Apocado", 3000, 3, 5, 2, 2);
	}
	
    @Test
	public void testInitial()
	{
		for(Recipe r : c.getRecipes())
		{
			assertNull(r);
		}
		assertEquals(c.checkInventory(), new Inventory().toString());
	}
		
	@Test
	public void testAddRecipe()
	{
		c.addRecipe(r1);
		c.addRecipe(r2);
		c.addRecipe(r3);
		assertEquals(c.getRecipes()[0], r1);
		assertEquals(c.getRecipes()[1], r2);
		assertEquals(c.getRecipes()[2], r3);
	}
	
	@Test
	public void testDeleteRecipe()
	{
		c.addRecipe(r1);
		c.deleteRecipe(0);
		assertNull(c.getRecipes()[0]);
	}
	
	@Test
	public void testEditingRecipe()
	{
		c.addRecipe(r1);
		assertEquals(c.editRecipe(0, r2), "Latte");
		
		Recipe edited = c.getRecipes()[0];
		assertEquals(edited.getName(), "Americano");
		assertEquals(edited.getPrice(), 1500);
		assertEquals(edited.getAmtCoffee(), 16);
		assertEquals(edited.getAmtMilk(), 0);
		assertEquals(edited.getAmtSugar(), 0);
		assertEquals(edited.getAmtChocolate(), 0);
	}
	
	@Test
	public void testAddInventory() throws InventoryException
	{
		Inventory i = new Inventory();
		c.addInventory("1", "3", "5", "7");
		i.addCoffee("1");
		i.addMilk("3");
		i.addSugar("5");
		i.addChocolate("7");
		assertEquals(c.checkInventory(), i.toString());
	}
	
	@Test
	public void testCheckInventory()
	{
		assertEquals(c.checkInventory(), "Coffee: 15\nMilk: 15\nSugar: 15\nChocolate: 15\n");
	}
	
	@Test
	public void testMakeCoffee()
	{
		Inventory i = new Inventory();
		c.addRecipe(r1);
		assertEquals(0, c.makeCoffee(0, 5000));
		i.useIngredients(r1);
		assertEquals(c.checkInventory(), i.toString());
	}

	@Test
	public void testEmptyRecipeCoffee()
	{
		Inventory i = new Inventory();
		
		assertEquals(10000, c.makeCoffee(0, 10000));
		assertEquals(7000, c.makeCoffee(2, 7000));
		assertEquals(c.checkInventory(), i.toString());
	}
	
	@Test
	public void testNotEnoughIngredientCoffee()
	{
		Inventory i = new Inventory();
		c.addRecipe(r2);
		
		assertEquals(3000, c.makeCoffee(0, 3000));
		i.useIngredients(r1);
		assertEquals(c.checkInventory(), i.toString());
	}
	
	@Test
	public void testNotEnoughMoneyCoffee()
	{
		Inventory i = new Inventory();
		
		c.addRecipe(r1);
		assertEquals(1000, c.makeCoffee(0, 1000));
		assertEquals(1000, c.makeCoffee(0, 6000));
		assertEquals(c.checkInventory(), i.toString());
	}
	
	@Test
	public void testDeleteRecipeStep()
	{
		c.addRecipe(r1);
		c.addRecipe(r2);
		c.addRecipe(r3);
		assertEquals(c.deleteRecipe(1), "Americano");
		assertEquals(c.deleteRecipe(0), "Latte");
		assertEquals(c.deleteRecipe(2), "Apocado");
	}
	
	@Test
	public void testDeleteEmptyRecipe()
	{
		assertNull(c.deleteRecipe(0));
	}
	
	@Test
	public void testDeleteOutOfBoundRecipe()
	{
		c.addRecipe(r1);
		assertNull(c.deleteRecipe(1));
	}
	
	@Test
	public void testEditEmptyRecipe()
	{
		assertNull(c.editRecipe(0, r1));
	}
	
	@Test
	public void testEditOutOfBoundRecipe()
	{
		c.addRecipe(r1);
		assertNull(c.editRecipe(1, r2));
	}
	
	@Test
	public void testUseIngredient()
	{
		Inventory i = new Inventory();
		i.useIngredients(r1);
		assertEquals(i.getCoffee(), 13);
		assertEquals(i.getMilk(), 5);
		assertEquals(i.getSugar(), 12);
		assertEquals(i.getChocolate(), 13);		
	}
	
	@Test
	public void testSetChocolateRecipeException() throws RecipeException
	{
		
		try {
			r1.setAmtChocolate("-1");
		}
		catch(RecipeException r)
		{
			assertTrue(true);
		}
		
		try {
			r1.setAmtChocolate("hello");
		}
		catch(RecipeException r)
		{
			assertTrue(true);
		}
	}
	
	@Test
	public void testSetCoffeeRecipeException() throws RecipeException
	{
		try {
			r1.setAmtCoffee("-1");
		}
		catch(RecipeException r)
		{
			assertTrue(true);
		}
		
		try {
			r1.setAmtCoffee("hello");
		}
		catch(RecipeException r)
		{
			assertTrue(true);
		}
	}
	
	@Test
	public void testSetMilkRecipeException() throws RecipeException
	{
		try {
			r1.setAmtMilk("-1");
		}
		catch(RecipeException r)
		{
			assertTrue(true);
		}
		
		try {
			r1.setAmtMilk("hello");
		}
		catch(RecipeException r)
		{
			assertTrue(true);
		}
	}
	
	@Test
	public void testSetSugarRecipeException() throws RecipeException
	{
		try {
			r1.setAmtSugar("-1");
		}
		catch(RecipeException r)
		{
			assertTrue(true);
		}
		
		try {
			r1.setAmtSugar("hello");
		}
		catch(RecipeException r)
		{
			assertTrue(true);
		}
	}
	
	@Test
	public void testSetPriceRecipeException() throws RecipeException
	{
		try {
			r1.setPrice("-1");
		}
		catch(RecipeException r)
		{
			assertTrue(true);
		}
		
		try {
			r1.setPrice("hello");
		}
		catch(RecipeException r)
		{
			assertTrue(true);
		}
	}
	
	@Test
	public void testSetName()
	{
		String test = "Caramel";
		r1.setName(test);
		assertEquals(test, r1.getName());
		
		r1.setName(null);
		assertEquals(test, r1.getName());
	}
	
	@Test
	public void testGetName()
	{
		String test = "Caramel";
		r1.setName(test);
		assertEquals(test, r1.getName());
		assertEquals(test, r1.toString());
	}
	
	@Test
	public void testSetPrice() throws RecipeException
	{
		String test = "3000";
		r1.setPrice(test);
		assertEquals(Integer.parseInt(test), r1.getPrice());
	}
	
	@Test
	public void testHashcode()
	{
		Recipe r = new Recipe();
		final int prime = 31;
		int result = 1;
		result = prime * result;
		assertEquals(result, r.hashCode());
		
		String test = "Caramel";
		r.setName(test);
		result = 1;
		result = prime * result + test.hashCode();
		assertEquals(result, r.hashCode());
	}
	
	@Test
	public void testEquals()
	{
		Recipe r_test = null;
		Recipe r_test2 = null;
		
		assertTrue(r1.equals(r1));
		assertFalse(r1.equals(r_test));
		assertFalse(r1.equals(c));
		
		r_test = new Recipe();
		r_test2 = new Recipe();
		assertFalse(r_test.equals(r1));
		assertTrue(r_test.equals(r_test2));
		
		assertFalse(r1.equals(r2));
		
		r_test.setName(r1.getName());
		assertTrue(r1.equals(r_test));
	}
	
	@Test
	public void testAddChocolateInventoryException() throws InventoryException
	{
		Inventory I_test = new Inventory();
		try {
			I_test.addChocolate("-1");
		}
		catch(InventoryException i)
		{
			assertTrue(true);
		}
		
		try {
			I_test.addChocolate("hello");
		}
		catch(InventoryException r)
		{
			assertTrue(true);
		}
	}
	
	@Test
	public void testAddCoffeeInventoryException() throws InventoryException
	{
		Inventory I_test = new Inventory();
		try {
			I_test.addCoffee("-1");
		}
		catch(InventoryException i)
		{
			assertTrue(true);
		}
		
		try {
			I_test.addCoffee("hello");
		}
		catch(InventoryException r)
		{
			assertTrue(true);
		}
	}
	
	@Test
	public void testAddSugarInventoryException() throws InventoryException
	{
		Inventory I_test = new Inventory();
		try {
			I_test.addSugar("-1");
		}
		catch(InventoryException i)
		{
			assertTrue(true);
		}
		
		try {
			I_test.addSugar("hello");
		}
		catch(InventoryException r)
		{
			assertTrue(true);
		}
	}
	
	@Test
	public void testAddMilkInventoryException() throws InventoryException
	{
		Inventory I_test = new Inventory();
		try {
			I_test.addMilk("-1");
		}
		catch(InventoryException i)
		{
			assertTrue(true);
		}
		
		try {
			I_test.addMilk("hello");
		}
		catch(InventoryException r)
		{
			assertTrue(true);
		}
	}
	
	@Test
	public void testEnoughIngredient() throws RecipeException
	{
		Inventory I_test = new Inventory();
		Recipe r_test1 = createRecipe("test1", 20, 20, 10, 10, 10);
		Recipe r_test2 = createRecipe("test2", 20, 10, 20, 10, 10);
		Recipe r_test3 = createRecipe("test3", 20, 10, 10, 20, 10);
		Recipe r_test4 = createRecipe("test4", 20, 10, 10, 10, 20);
		
		assertFalse(I_test.useIngredients(r_test1));
		assertFalse(I_test.useIngredients(r_test2));
		assertFalse(I_test.useIngredients(r_test3));
		assertFalse(I_test.useIngredients(r_test4));
		
	}
	
	@Test
	public void testSetChocolateInventory()
	{
		Inventory I_test = new Inventory();
		I_test.setChocolate(-1);
		assertEquals(15, I_test.getChocolate());
		
		I_test.setChocolate(1);
		assertEquals(1, I_test.getChocolate());
	}
	
	@Test
	public void testSetCoffeeInventory()
	{
		Inventory I_test = new Inventory();
		I_test.setCoffee(-1);
		assertEquals(15, I_test.getCoffee());
		
		I_test.setCoffee(1);
		assertEquals(1, I_test.getCoffee());
	}
	
	@Test
	public void testSetMilkInventory()
	{
		Inventory I_test = new Inventory();
		I_test.setMilk(-1);
		assertEquals(15, I_test.getMilk());
		
		I_test.setMilk(1);
		assertEquals(1, I_test.getMilk());
	}
	
	@Test
	public void testSetSugarInventory()
	{
		Inventory I_test = new Inventory();
		I_test.setSugar(-1);
		assertEquals(15, I_test.getSugar());
		
		I_test.setSugar(1);
		assertEquals(1, I_test.getSugar());
	}
	
	@Test
	public void testAddDuplicateRecipe()
	{
		RecipeBook test = new RecipeBook();
		test.addRecipe(r1);
		assertFalse(test.addRecipe(r1));
	}
}
