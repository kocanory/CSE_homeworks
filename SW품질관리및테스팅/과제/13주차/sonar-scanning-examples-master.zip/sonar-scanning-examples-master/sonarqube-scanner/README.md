# SonarQube-Scanner

Examples of SonarQube Scanner usage.  Browse folder, language samples and properties file.
