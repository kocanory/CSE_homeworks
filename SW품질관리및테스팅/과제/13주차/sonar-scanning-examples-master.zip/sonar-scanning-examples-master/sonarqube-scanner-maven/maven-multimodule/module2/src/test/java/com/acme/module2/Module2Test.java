package com.acme.module2;

import org.junit.Test;

public class Module2Test {

  @Test
  public void coveredByUnitTest() {
    new Module2().coveredByUnitTest();
  }
}
