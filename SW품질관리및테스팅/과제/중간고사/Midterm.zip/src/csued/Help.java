package csued;
import java.io.*;

public class Help

{

  //***************************************************************************
  public static void General()
  {
	  System.out.println("Available option: ");
	  System.out.println("\t-Q");
	  System.out.println("\t-X");
	  System.out.println("\t-T");
	  System.out.println("\t-E");
	  System.out.println("\t-N");
	  System.out.println("\t-B");
	  System.out.println("\t-W");
	  System.out.println("\t-C");
	  System.out.println("\t-L");
	  System.out.println("\t-S");
	  System.out.println("\t-D");
	  System.out.println("\t-A");
	  System.out.println("\t-F");
	  System.out.println("\t-R");
	  System.out.println("\t-Y");
	  System.out.println("\t-Z");
	  System.out.println("\t-P");
	  System.out.println("\t-I");
	  System.out.println("\t-K");
	  System.out.println("\t-O");
	  System.out.println("\t-M\n");
	  System.out.println("Want to know more impormation, H {command}");
  }

  //***************************************************************************
  public static void Command(char cmd)
  {
      switch (Character.toUpperCase(cmd)) 
      {

        //========= TERMINATE EDITOR COMMANDS =================================
       
          case 'Q': // QUIT (& Update File) Command
        	  		System.out.println("Terminates editing and updates the edit with the editing changes.");
        	  		System.out.println("command : Q ");
                    break;

          case 'X': // EXIT (& DO NOT Update File) Command
  	  				System.out.println("Terminates editing and does NOT update the edit file. The changes are ignored.");
  	  				System.out.println("command : X");
                    break;

        //========= TERMINATE EDITOR COMMANDS =================================

          case 'H': // HELP (with optional command argument) Command
  					System.out.println("By itself provides a short list of the editor comamnds and with an argument (which must be the letter of a valid command) provides a short description of the command.");
  					System.out.println("command : H {cmd}");
                    break;
       
        //========= MOVE/SHOW CURRENT-LINE-NUMBER/CLN EDITOR COMMANDS =========

          case 'T': // TOP (Move CLN to Top of File) Command
  					System.out.println("Positions CLN to the top of the file (to line 1)");
  					System.out.println("command : T");
                    break;

          case 'E': // END (Move CLN to End of File) Command
  					System.out.println("Positions CLN to the end/bottom of the file (to last line)");
  					System.out.println("command : E");
                    break;

          case 'N': // NEXT Lines (Move CLN forward) Command
  					System.out.println("Moves CLN number of lines forward/down the file (from CLN)");
  					System.out.println("command : N nl");
                    break;

          case 'B': // BACK Lines (Move CLN backward) Command
  					System.out.println("Moves CLN number of lines backwards/up the file (from CLN");
  					System.out.println("command : B nl");
                    break;

          case 'W': // WHERE (Print CLN) Command
  					System.out.println("Prints \"At Edit File Line x\" where x is the value of CLN");
  					System.out.println("command : W");
                    break;

          case 'C': // COUNT (Print Total File Lines) Command
  					System.out.println("Prints \"Total Edit File Lines: x\" where x is number of lines in the edit file");
  					System.out.println("command : C"); 
                    break;

        //========= PRINT LINES EDITOR COMMANDS ===============================

          case 'L': // LIST (Move CLN) Lines Command
  					System.out.println("Lists/Prints number of file lines starting at CLN (and leaves CLN at last line printed)");
  					System.out.println("command : L nl");
                    break;

          case 'S': // SHOW (DO NOT Move CLN) Lines Command
  					System.out.println("Shows/Prints number of file lines starting at CLN");
  					System.out.println("command : S nl");
                    break;

        //========= DELETE/ADD LINES EDITOR COMMANDS ==========================

          case 'D': // DELETE Lines Command
  					System.out.println("Deletes the number of file lines starting at CLN and leaves CLN positioned to the line after the last line deleted");
  					System.out.println("command : D nl");
                    break;

          case 'A': // ADD Lines Command
  					System.out.println("Adds lines (typed/entered) to the edit file AFTER the CLN line number. Enter/type a null line (i.e. just hit return on a new line) by itself to terminate entry. CLN is positioned to the last line entered.");
  					System.out.println("command : A");
                    break;

        //========= STRING FIND/REPLACE LINES EDITOR COMMANDS =================

          case 'F': // FIND String In Lines Command
  					System.out.println("Finds and prints the line, or lines staring at CLN, that contain one or more occurrences of the string. The first and last characters of the string must be the same to delimit the string and are not considered during string matching. CLN is positioned to the last line a match was attempted");
  					System.out.println("command : F nl str");
                    break;

          case 'R': // REPLACE String In Lines Command
  					System.out.println("Finds and replaces all occurrences of the old string with the new string starting at CLN. Any line that is changed is printed. The first and last characters of each string must be the same to delimit the string and are not considered during string matching or replacement.");
  					System.out.println("command : R nl oldstr newstr");
                    break;

        //========= COPY/CUT & PASTE LINES EDITOR COMMANDS ====================

          case 'Y': // YANK (to Yank Buffer) Lines Command
  					System.out.println("Yanks and COPIES the lines starting at CLN to the internal line buffer. Y replaces the previous contents of the internal line buffer with the newly yanked line(s). CLN is positioned to the last line yanked.");
  					System.out.println("command : Y nl");
                    break;

          case 'Z': // YANK DELETE (to Yank Buffer) Lines Command
  					System.out.println("Yanks and DELETES the lines starting at CLN to the internal line buffer. Z replaces the previous contents of the internal line buffer with the newly deleted line(s). CLN is positioned to the line after the last line deleted.");
  					System.out.println("command : Z nl");
                    break;

          case 'P': // PUT (Yank Buffer) Lines Command
  					System.out.println("Puts the entire contents of the internal line buffer after the CLN and leaves CLN positioned to the last line put. The internal line buffer remains unaltered after the put. If the internal line buffer is empty then P has no effect on the edit file.");
  					System.out.println("command : P");
                    break;

        //========= INDEX/KEYWORD EDITOR COMMANDS =============================

          case 'I': // INDEX Keywords Command
  					System.out.println("Indexes the keywords at the top of the edit file (i.e. those lines appearing at the top of the file beginning with the character \'\'. An internal table is created with edit file line numbers of the edit file lines that contain each keyword. Warning: if other commands are used to change the file, then this command should be used again to re-index the file. This command does not affect CLN.");
  					System.out.println("command : I");
                    break;

          case 'K': // Print KEYWORD In Which Lines Command
  					System.out.println("Keyword prints the line numbers from the keyword table created by the I(ndex) command for the speci\fed keyword. The first and last characters of the keyword must be the same to delimit the string and are not considered part of the keyword. If I has not yet been issued before K, then K will simply report that the keyword was not found. This command does not affect CLN.");
  					System.out.println("command : K keyword");
                    break;

        //========= SPECIAL EDITOR COMMANDS ===================================

          case 'O': // ORDER (Sort L-H) Lines Command
  					System.out.println("Orders/Sorts the lines L-H lexicographically starting at the CLN and leaves CLN positioned to the last line sorted. Note that trailing blanks at the end of lines does affect sorting.");
  					System.out.println("command : O nl");
                    break;

          case 'M': // MARGIN (Set Margins/Window) Command
  					System.out.println("Sets column margins/window (default starting values are 1 and 80) for use with the F, R & O commands. That is, these commands will search/sort only within the de\fned margins/window. This command does not affect CLN.");
  					System.out.println("command : M c1 c2");
                    break;
      }
  }
} // EndClass Help