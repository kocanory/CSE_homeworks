package csued;

import static org.junit.Assert.*;

import java.io.IOException;

import org.junit.Before;
import org.junit.Test;

public class csued_Test {
	
	String args[] = {"test.txt"};
	Cmd_Driver cmd_driver_test;
	DLL dll_test;
	External_File external_file_test;
	File_Buffer file_buffer_test;
	Init_Exit init_exit_test;
	MyVector myvector_test;
	PQueue pqueue_test;
	Queue queue_test;
	UserCmd usercmd_test;
	Msg msg_test;
	
	@Before
	public void Setup() throws IOException
	{
		cmd_driver_test = new Cmd_Driver();
		dll_test = new DLL();
		external_file_test = new External_File();
		file_buffer_test = new File_Buffer();
		init_exit_test = new Init_Exit(args, file_buffer_test);
		myvector_test = new MyVector();
		pqueue_test = new PQueue();
		queue_test = new Queue();
		usercmd_test = new UserCmd();
		msg_test = new Msg();
	}
	
	@Test
	public void test_setCmdLine()
	{
		usercmd_test.setCmdLine("test");
		assertEquals("test", usercmd_test.getCmdLine());
	}

	@Test
	public void test_setCmdName()
	{
		usercmd_test.setCmdName('1');
		assertEquals('1', usercmd_test.getCmdName());
	}
	
	@Test
	public void test_setIntArgs()
	{
		usercmd_test.setIntArgs(1, 1);
		assertEquals(1, usercmd_test.getIntArgs(1));
	}
	
	@Test
	public void test_setStrArgs()
	{
		usercmd_test.setStrArgs("test", 1);
		assertEquals("test", usercmd_test.getStrArgs(1));
	}
	
	@Test
	public void test_setOptArgs()
	{
		usercmd_test.setOptArgs("Opt", 1);
		assertEquals("Opt", usercmd_test.getOptArgs(1));
	}
	
	@Test
	public void test_setOkSyntax()
	{
		usercmd_test.setOkSyntax();
		assertEquals(true, usercmd_test.getOkSyntax());
	}
	
	@Test
	public void test_getCmdLine()
	{
		assertEquals(null, usercmd_test.getCmdLine());
	}

	@Test
	public void test_getCmdName()
	{
		assertEquals(' ', usercmd_test.getCmdName());
	}
	
	@Test
	public void test_getIntArgs()
	{
		assertEquals(0, usercmd_test.getIntArgs(0));
		assertEquals(0, usercmd_test.getIntArgs(1));
		assertEquals(0, usercmd_test.getIntArgs(2));
		assertEquals(0, usercmd_test.getIntArgs(3));
		assertEquals(0, usercmd_test.getIntArgs(4));
	}
	
	@Test
	public void test_getStrArgs()
	{
		assertEquals(null, usercmd_test.getStrArgs(0));
		assertEquals(null, usercmd_test.getStrArgs(1));
		assertEquals(null, usercmd_test.getStrArgs(2));
		assertEquals(null, usercmd_test.getStrArgs(3));
		assertEquals(null, usercmd_test.getStrArgs(4));
	}
	
	@Test
	public void test_getOptArgs()
	{
		assertEquals(null, usercmd_test.getOptArgs(0));
		assertEquals(null, usercmd_test.getOptArgs(1));
		assertEquals(null, usercmd_test.getOptArgs(2));
		assertEquals(null, usercmd_test.getOptArgs(3));
		assertEquals(null, usercmd_test.getOptArgs(4));
	}
	
	@Test
	public void test_getOkSyntax()
	{
		assertEquals(false, usercmd_test.getOkSyntax());
	}
	
	@Test
	public void test_OpenR() throws IOException
	{
		assertEquals(false, external_file_test.openR("test.txt"));
	}
	
	@Test
	public void test_OpenR_exception() throws IOException
	{
		assertEquals(true, external_file_test.openR(""));
	}
	
	@Test
	public void test_OpenW() throws IOException
	{
		assertEquals(false, external_file_test.openW("test.txt"));
	}
		
	@Test
	public void test_OpenW_exception() throws IOException
	{
		assertEquals(true, external_file_test.openW(""));
	}
	
	@Test
	public void test_writeAndgetLine() throws IOException
	{
		String test = "test";
		external_file_test.openW("test.txt");
		external_file_test.write(test);
		external_file_test.close();
		
		external_file_test.openR("test.txt");
		assertEquals(test, external_file_test.getLine());
		external_file_test.close();
	}
	
	@Test
	public void test_writelnAndgetLine() throws IOException
	{
		String test = "test";
		external_file_test.openW("test.txt");
		external_file_test.writeln(test);
		external_file_test.close();
		
		external_file_test.openR("test.txt");
		assertEquals(test, external_file_test.getLine());
		external_file_test.close();
	}
	
	
	@Test
	public void test_emptyDll()
	{
		assertEquals(true, dll_test.emptyDLL());
	}
	
	@Test
	public void test_clearDll()
	{
		dll_test.insertDLL(0, "test1");
		dll_test.insertDLL(1, "test2");
		dll_test.insertDLL(2, "test3");
		dll_test.insertDLL(3, "test4");
		dll_test.clearDLL();
		assertEquals(true, dll_test.emptyDLL());
	}
	
	@Test
	public void test_insertDLL()
	{
		String test = "test";
		dll_test.insertDLL(0, test);
		assertEquals(test, dll_test.getDLL(1));
	}
	
	@Test
	public void test_putDLL()
	{
		String test = "test";
		dll_test.insertDLL(0, test);
		dll_test.putDLL(1, "test1");
		assertEquals("test1", dll_test.getDLL(1));
	}
	
	@Test
	public void test_deleteDLL()
	{
		String test = "test";
		dll_test.insertDLL(0, test);
		dll_test.deleteDLL(1);
		assertEquals(null, dll_test.getDLL(0));
	}
	
	@Test
	public void test_addLine()
	{
		file_buffer_test.AddLine(0, "test");
		assertEquals("test", file_buffer_test.GetLine(1));
	}
	
	@Test
	public void test_putLine()
	{
		file_buffer_test.AddLine(0, "test");
		file_buffer_test.PutLine(1, "test1");
		assertEquals("test1", file_buffer_test.GetLine(1));
	}
	
	@Test
	public void test_delLine()
	{
		file_buffer_test.AddLine(0, "test");
		file_buffer_test.DelLine(1);
		assertEquals(null, file_buffer_test.GetLine(0));
	}
	
	@Test
	public void test_getUpdateFlag()
	{
		file_buffer_test.setUpdateFlag(false);
		assertEquals(false, file_buffer_test.getUpdateFlag());
	}
	
	@Test
	public void test_getCLN()
	{
		assertEquals(0, file_buffer_test.GetCLN());
	}
	
	@Test
	public void test_Start_failed() throws IOException
	{
		assertEquals(false, init_exit_test.Start_Failed());
		
		String args2[] = {"test", "test"};
		init_exit_test = new Init_Exit(args2, file_buffer_test);
		assertEquals(true, init_exit_test.Start_Failed());
	}
	
	@Test
	public void test_size()
	{
		assertEquals(0, myvector_test.size());
	}
	
	@Test
	public void test_capacity()
	{
		assertEquals(100, myvector_test.capacity());
	}
	
	@Test
	public void test_empty()
	{
		assertEquals(true, myvector_test.isEmpty());
	}
	
	@Test
	public void test_addtElement()
	{
		myvector_test.addElement("test");
		assertEquals(true, myvector_test.contains("test"));
		assertEquals("test", myvector_test.elementAt(0));
	}
	
	@Test
	public void test_setElementAt()
	{
		myvector_test.addElement("test");
		myvector_test.setElementAt("test1", 0);
		assertEquals(true, myvector_test.contains("test1"));
		assertEquals("test1", myvector_test.elementAt(0));
	}
	
	@Test
	public void test_contains()
	{
		myvector_test.addElement("test");
		assertEquals(true, myvector_test.contains("test"));
		assertEquals(false, myvector_test.contains("test1"));
	}
	
	@Test
	public void test_insertElementAt()
	{
		myvector_test.addElement("test");
		myvector_test.insertElementAt("test0", 0);
		assertEquals(true, myvector_test.contains("test"));
		assertEquals(true, myvector_test.contains("test0"));
		assertEquals("test0", myvector_test.elementAt(0));
		assertEquals("test", myvector_test.elementAt(1));
	}
	
	@Test
	public void test_removeElement()
	{
		myvector_test.addElement("test");
		myvector_test.removeElement("test");
		assertEquals(false, myvector_test.contains("test"));
		assertEquals(null, myvector_test.elementAt(0));
		
		assertEquals(false, myvector_test.removeElement("test"));
	}
	
	@Test
	public void test_removeElementAt()
	{
		myvector_test.addElement("test");
		myvector_test.removeElementAt(0);
		assertEquals(false, myvector_test.contains("test"));
		assertEquals(null, myvector_test.elementAt(0));
		
		myvector_test.addElement("test");
		myvector_test.addElement("test1");
		myvector_test.addElement("test2");
		myvector_test.removeElementAt(1);
		assertEquals(false, myvector_test.contains("test1"));
		assertEquals("test2", myvector_test.elementAt(1));
	}
	
	@Test
	public void test_removeAllElements()
	{
		myvector_test.addElement("test");
		myvector_test.addElement("test1");
		myvector_test.addElement("test2");
		myvector_test.removeAllElements();
		assertEquals(0, myvector_test.size());
		assertEquals(false, myvector_test.contains("test"));
		assertEquals(false, myvector_test.contains("test1"));
		assertEquals(false, myvector_test.contains("test2"));
		
	}
	
	@Test
	public void test_insertQueue()
	{
		pqueue_test.insertQueue(0, "test");
		assertEquals("test", pqueue_test.getQueue(1));
	}
	
	@Test
	public void test_getQueue()
	{
		pqueue_test.insertQueue(0, "test");
		pqueue_test.insertQueue(1, "test1");
		assertEquals(null, pqueue_test.getQueue(0));
		assertEquals("test", pqueue_test.getQueue(1));
		assertEquals("test1", pqueue_test.getQueue(2));
	}
	
	@Test
	public void test_deleteQueue()
	{
		pqueue_test.insertQueue(0, "test");
		pqueue_test.insertQueue(1, "test1");
		pqueue_test.deleteQueue(1);
		assertEquals("test1", pqueue_test.getQueue(1));
	}
	
	@Test
	public void test_enQueue()
	{
		queue_test.enQueue("test");
		assertEquals("test", queue_test.deQueue());
	}
	
	@Test
	public void test_clearQueue()
	{
		queue_test.enQueue("test");
		queue_test.clearQueue();
		assertEquals(true, queue_test.emptyQueue());
	}
	
	@Test
	public void test_numberQueue()
	{
		queue_test.enQueue("test");
		assertEquals(1, queue_test.numberQueue());
	}
	
	@Test
	public void test_Help()
	{
		try {
			Help.General();
			Help.Command('q');
			Help.Command('x');
			Help.Command('t');
			Help.Command('e');
			Help.Command('n');
			Help.Command('b');
			Help.Command('w');
			Help.Command('c');
			Help.Command('l');
			Help.Command('s');
			Help.Command('d');
			Help.Command('a');
			Help.Command('f');
			Help.Command('r');
			Help.Command('y');
			Help.Command('z');
			Help.Command('p');
			Help.Command('i');
			Help.Command('k');
			Help.Command('o');
			Help.Command('m');
			Help.Command('h');
			assertTrue(true);
		}
		catch(Exception e){
			assertFalse(true);
		}
	}
	
	@Test
	public void test_Parser()
	{
		try {Parser.parseCmdLine();
		assertTrue(true);}
		catch (Exception e){ assertFalse(true);}
	}
	
	@Test
	public void test_RunCmd() throws IOException
	{
		usercmd_test.setCmdName('q');
		assertEquals(true, cmd_driver_test.RunCmd(file_buffer_test, usercmd_test));
		
		usercmd_test.setCmdName('x');
		assertEquals(true, cmd_driver_test.RunCmd(file_buffer_test, usercmd_test));
	
		usercmd_test.setCmdName('a');
		assertEquals(false, cmd_driver_test.RunCmd(file_buffer_test, usercmd_test));
				
		usercmd_test.setCmdName('h');
		assertEquals(false, cmd_driver_test.RunCmd(file_buffer_test, usercmd_test));
		usercmd_test.setOptArgs("q", 1);
		assertEquals(false, cmd_driver_test.RunCmd(file_buffer_test, usercmd_test));
		
		usercmd_test.setCmdName('t');
		assertEquals(false, cmd_driver_test.RunCmd(file_buffer_test, usercmd_test));
		
		usercmd_test.setCmdName('e');
		assertEquals(false, cmd_driver_test.RunCmd(file_buffer_test, usercmd_test));
		
		usercmd_test.setCmdName('n');
		usercmd_test.setIntArgs(1, 1);
		assertEquals(false, cmd_driver_test.RunCmd(file_buffer_test, usercmd_test));
		
		usercmd_test.setCmdName('b');
		usercmd_test.setIntArgs(1, 1);
		assertEquals(false, cmd_driver_test.RunCmd(file_buffer_test, usercmd_test));
		
		usercmd_test.setCmdName('w');
		assertEquals(false, cmd_driver_test.RunCmd(file_buffer_test, usercmd_test));
		
		usercmd_test.setCmdName('c');
		assertEquals(false, cmd_driver_test.RunCmd(file_buffer_test, usercmd_test));
		
		usercmd_test.setCmdName('l');
		usercmd_test.setIntArgs(1, 1);
		assertEquals(false, cmd_driver_test.RunCmd(file_buffer_test, usercmd_test));
		
		usercmd_test.setCmdName('s');
		usercmd_test.setIntArgs(1, 1);
		assertEquals(false, cmd_driver_test.RunCmd(file_buffer_test, usercmd_test));
	
		usercmd_test.setCmdName('d');
		usercmd_test.setIntArgs(1, 1);
		assertEquals(false, cmd_driver_test.RunCmd(file_buffer_test, usercmd_test));
		
		usercmd_test.setCmdName('f');
		usercmd_test.setIntArgs(1, 1);
		usercmd_test.setStrArgs("have", 1);
		assertEquals(false, cmd_driver_test.RunCmd(file_buffer_test, usercmd_test));
		
		usercmd_test.setCmdName('r');
		usercmd_test.setIntArgs(1, 1);
		usercmd_test.setStrArgs("have", 1);
		usercmd_test.setStrArgs("have2", 2);
		assertEquals(false, cmd_driver_test.RunCmd(file_buffer_test, usercmd_test));
		
		usercmd_test.setCmdName('y');
		usercmd_test.setIntArgs(1, 1);
		assertEquals(false, cmd_driver_test.RunCmd(file_buffer_test, usercmd_test));
	
		usercmd_test.setCmdName('z');
		usercmd_test.setIntArgs(1, 1);
		assertEquals(false, cmd_driver_test.RunCmd(file_buffer_test, usercmd_test));
	
		usercmd_test.setCmdName('p');
		assertEquals(false, cmd_driver_test.RunCmd(file_buffer_test, usercmd_test));

		usercmd_test.setCmdName('i');
		assertEquals(false, cmd_driver_test.RunCmd(file_buffer_test, usercmd_test));
		
		usercmd_test.setCmdName('k');
		usercmd_test.setStrArgs("have", 1);
		assertEquals(false, cmd_driver_test.RunCmd(file_buffer_test, usercmd_test));
		
		usercmd_test.setCmdName('o');
		usercmd_test.setIntArgs(1, 1);
		assertEquals(false, cmd_driver_test.RunCmd(file_buffer_test, usercmd_test));
		
		usercmd_test.setCmdName('m');
		usercmd_test.setIntArgs(1, 1);
		usercmd_test.setIntArgs(2, 2);
		assertEquals(false, cmd_driver_test.RunCmd(file_buffer_test, usercmd_test));
		
		usercmd_test.setCmdName('1');
		assertEquals(false, cmd_driver_test.RunCmd(file_buffer_test, usercmd_test));
	}
	
}
